define("TABLE_WIDTH_MAIN", $_CONFIG["table_width_main"], true);
define("SKIN_DIR", $_CONFIG["skin_dir"], true);